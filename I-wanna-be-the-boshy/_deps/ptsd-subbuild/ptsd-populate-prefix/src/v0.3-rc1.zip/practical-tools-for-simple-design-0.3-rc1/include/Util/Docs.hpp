#error This file is only for documentation purposes only

/**
 * @brief Useful tools for development
 */
namespace Util {}
